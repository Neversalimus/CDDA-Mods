"""Reproduce upstream v8.5's header declarations in an external build checkout.

This is NOT a host implementation or a runtime compatibility claim.
"""
import hashlib
from pathlib import Path
import sys

header = Path(sys.argv[1]) / 'ncmm_api.h'
raw = header.read_bytes()
# Git may check out text using CRLF on Windows; hash canonical upstream LF.
raw = raw.replace(b'\r\n', b'\n')
expected = '4f41fcaa512fbade3497705ad6fcaf4e5f2dd837c38ae66852cccac7495277ea'
if hashlib.sha256(raw).hexdigest() != expected:
    raise SystemExit('External SDK differs from pinned c15fbff6 header; refusing patch')
text = raw.decode('utf-8')
old = '    int64_t ( *gameplay_metric_get_i64 )( const char *metric_id );'
assert text.count(old) == 1 and text.count('#define NCMM_API_VERSION_MINOR 4u') == 1
text = text.replace('#define NCMM_API_VERSION_MINOR 4u', '#define NCMM_API_VERSION_MINOR 5u')
text = text.replace(old, old + '\n    int ( *world_mod_active )( const char *mod_id );')
header.write_bytes(text.encode('utf-8'))
print('Prepared compile-only external API 1.5 header; matching runtime still required')
